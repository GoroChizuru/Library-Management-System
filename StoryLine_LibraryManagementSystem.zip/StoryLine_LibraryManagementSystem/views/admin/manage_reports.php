<?php
require "../../includes/auth.php";
check_role("admin", "../../views/login.php"); // Redirect non-admin users to login
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/report.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <h4 class="text-center mb-4">Admin</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="manage_user.php" class="nav-link">Manage Users</a>
                </li>
                <li class="nav-item">
                    <a href="manage_books.php" class="nav-link">Manage Books</a>
                </li>
                <li class="nav-item">
                    <a href="manage_reports.php" class="nav-link">Generate Reports</a>
                </li>
                <li class="nav-item">
                    <a href="../../includes/logout.php" class="nav-link text-danger">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content container mt-5">
            <h1 class="text-center mb-4">Generate Report</h1>

            <!-- Button Section -->
            <div class="button-group">
            <div class="button-group">
    <a href="../../api/reports.php?status=Available" target="_blank" class="custom-button">Generate Available Books</a>
    <a href="../../api/reports.php?status=Borrowed" target="_blank" class="custom-button">Generate Borrowed Books</a>
    <a href="../../api/reports.php" target="_blank" class="custom-button">Generate PDF Report</a>
</div>

        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    
</body>
</html>
