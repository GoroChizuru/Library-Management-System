<?php
require "../../includes/auth.php";
check_role("admin", "../../views/login.php"); // Redirect non-admin users to login
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/manage_user.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <h4 class="text-center mb-4">Admin</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="manage_user.php" class="nav-link active">Manage Users</a>
                </li>
                <li class="nav-item">
                    <a href="manage_books.php" class="nav-link">Manage Books</a>
                </li>
                <li class="nav-item">
                    <a href="manage_reports.php" class="nav-link">Generate Reports</a>
                </li>
                <li class="nav-item">
                    <a href="../../includes/logout.php" class="nav-link text-danger">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content container mt-5">
            <h1 class="text-center mb-4">Manage Users</h1>

            <!-- User Form -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form id="userForm" class="row g-3" onsubmit="event.preventDefault(); handleUserForm();">
                        <input type="hidden" id="user-id"> <!-- Hidden input to track edit ID -->
                        <div class="col-md-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" id="username" class="form-control" placeholder="Username" required>
                        </div>
                        <div class="col-md-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" id="password" class="form-control" placeholder="Password" required>
                        </div>
                        <div class="col-md-3">
                            <label for="role" class="form-label">Role</label>
                            <select id="role" class="form-control" required>
                                <option value="" disabled selected>Select Role</option>
                                <option value="Admin">admin</option>
                                <option value="Librarian">librarian</option>
                            </select>
                        </div>
                        <div class="col-12 text-center mt-3">
                            <button type="submit" id="btn-submit" class="btn btn-primary">Create User</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- User Table -->
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="user-display">
                        <!-- Dynamic rows will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm" class="row g-3">
                        <input type="hidden" id="edit-user-id">
                        <div class="col-12">
                            <label for="edit-username" class="form-label">Username</label>
                            <input type="text" id="edit-username" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label for="edit-password" class="form-label">Password</label>
                            <input type="password" id="edit-password" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label for="edit-role" class="form-label">Role</label>
                            <select id="edit-role" class="form-control" required>
                                <option value="" disabled selected>Select Role</option>
                                <option value="admin">admin</option>
                                <option value="librarian">librarian</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="updateUserFromModal()">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../assets/js/user.js"></script>
</body>
</html>
