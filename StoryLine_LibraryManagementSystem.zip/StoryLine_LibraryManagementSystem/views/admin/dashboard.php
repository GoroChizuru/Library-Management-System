<?php
require "../../includes/auth.php";
check_role("admin", "../../views/login.php"); // Redirect non-admin users to login
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <h4 class="text-center mb-4">Admin</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="manage_user.php" class="nav-link">Manage Users</a>
                </li>
                <li class="nav-item">
                    <a href="manage_books.php" class="nav-link">Manage Books</a>
                </li>
                <li class="nav-item">
                    <a href="manage_reports.php" class="nav-link">Generate Reports</a>
                </li>
                <li class="nav-item">
                    <a href="../../includes/logout.php" class="nav-link text-danger">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content container mt-5">
            <h1 class="text-center mb-4">Dashboard</h1>

            <!-- Statistics Section -->
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <p class="card-text display-5" id="total-users">0</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Total Books</h5>
                            <p class="card-text display-5" id="total-books">0</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Books Borrowed</h5>
                            <p class="card-text display-5" id="books-borrowed">0</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Example: Fetch statistics dynamically (mockup)
        document.addEventListener('DOMContentLoaded', () => {
            fetch('../../api/dashboard_stats.php')
                .then((response) => response.json())
                .then((data) => {
                    document.getElementById('total-users').textContent = data.totalUsers;
                    document.getElementById('total-books').textContent = data.totalBooks;
                    document.getElementById('books-borrowed').textContent = data.booksBorrowed;
                })
                .catch((error) => console.error('Error fetching stats:', error));
        });
    </script>
</body>
</html>
