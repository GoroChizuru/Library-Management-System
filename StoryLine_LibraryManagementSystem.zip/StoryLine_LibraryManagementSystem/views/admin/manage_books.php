<?php
require "../../includes/auth.php";
check_role("admin", "../../views/login.php"); // Redirect non-admin users to login
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/manage_books.css"> 
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <h4 class="text-center mb-4">Admin</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a href="manage_user.php" class="nav-link">Manage Users</a>
                </li>
                <li class="nav-item">
                    <a href="manage_books.php" class="nav-link active">Manage Books</a>
                </li>
                <li class="nav-item">
                    <a href="manage_reports.php" class="nav-link">Generate Reports</a>
                </li>
                <li class="nav-item">
                    <a href="../../includes/logout.php" class="nav-link text-danger">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content container mt-5">
            <h1 class="text-center mb-4">Manage Books</h1>

            <!-- Book Form -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <form id="bookForm" class="row g-3">
                        <div class="col-md-3">
                            <label for="bookTitle" class="form-label">Book Title</label>
                            <input type="text" id="bookTitle" class="form-control" placeholder="Book Title" required>
                        </div>
                        <div class="col-md-3">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" id="author" class="form-control" placeholder="Author" required>
                        </div>
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" class="form-control" required>
                                <option value="" disabled selected>Select Status</option>
                                <option value="Borrowed">Borrowed</option>
                                <option value="Available">Available</option>
                            </select>
                        </div>

                        <div class="col-12 text-center mt-3">
                            <button type="submit" class="btn btn-primary">Create Book</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Book Table -->
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Book ID</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="book-display">
                        <!-- Dynamic rows will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

   <!-- Edit Book Modal -->
<div class="modal fade" id="editBookModal" tabindex="-1" aria-labelledby="editBookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBookModalLabel">Edit Book</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editBookForm" class="row g-3">
                    <input type="hidden" id="edit-book-id">
                    <div class="col-12">
                        <label for="edit-book-title" class="form-label">Book Title</label>
                        <input type="text" id="edit-book-title" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <label for="edit-author" class="form-label">Author</label>
                        <input type="text" id="edit-author" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <label for="edit-status" class="form-label">Status</label>
                        <select id="edit-status" class="form-control" required>
                            <option value="" disabled selected>Select Status</option>
                            <option value="Borrowed">Borrowed</option>
                            <option value="Available">Available</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="updateBookFromModal()">Save Changes</button>
            </div>
        </div>
    </div>
</div>


    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="../../assets/js/book.js"></script>
</body>
</html>
