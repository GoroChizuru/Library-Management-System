<?php
require "../../includes/auth.php";
check_role("librarian", "../../views/login.php"); // Redirect non-librarian users to login
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/borrow_return.css">

</head>

<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar">
            <h4 class="text-center mb-4">Librarian</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="borrow_return.php" class="nav-link active">Manage Books</a>
                </li>
                <li class="nav-item">
                    <a href="../../includes/logout.php" class="nav-link text-danger">Logout</a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content container mt-5">
            <h1 class="text-center mb-4">Book Status</h1>

            <!-- Book Table -->
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Book ID</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="book-display">
                        <!-- Dynamic rows will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../assets/js/booklib.js"></script>
</body>

</html>