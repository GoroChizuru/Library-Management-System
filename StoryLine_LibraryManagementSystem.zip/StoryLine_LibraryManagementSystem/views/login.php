<?php
session_start();

// If user is already logged in, redirect based on their role
if (isset($_SESSION["role"])) {
    if ($_SESSION["role"] === "admin") {
        header("Location: admin/dashboard.php");
        exit();
    } elseif ($_SESSION["role"] === "librarian") {
        header("Location: librarian/borrow_return.php");
        exit();
    } 
}

// Capture error messages passed via query parameters (if any)
$error = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Login</title>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    min-height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center; 
    align-items: center;
    background: linear-gradient(135deg, #1e0553 0%, #3d0a6b 100%);
    overflow: hidden;
}


.container {
    display: flex;
    justify-content: center; /* Center horizontally */
    align-items: center;    /* Center vertically */
    min-height: 100vh;      /* Full viewport height */
    position: relative;     /* Allows absolute-positioned child elements */
}

.login-container {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 40px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}


/* Stars Effect */
.stars {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    background-image: 
        radial-gradient(2px 2px at 20px 30px, #ffffff, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 40px 70px, #ffffff, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 50px 160px, #ffffff, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 90px 40px, #ffffff, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 130px 80px, #ffffff, rgba(0,0,0,0)),
        radial-gradient(2px 2px at 160px 120px, #ffffff, rgba(0,0,0,0));
    background-repeat: repeat;
    background-size: 200px 200px;
    animation: twinkle 5s infinite;
    opacity: 0.4;
}

/* Mountains Effect */
.mountains {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 30vh;
    background: 
        linear-gradient(transparent 0%, #2a0f45 90%),
        repeating-linear-gradient(45deg, 
            #2a0f45 0%, #2a0f45 10%,
            #250d3d 10%, #250d3d 20%);
    clip-path: polygon(
        0% 100%, 20% 65%, 40% 90%, 
        60% 62%, 80% 85%, 100% 55%, 
        100% 100%
    );
}

/* Trees Effect */
.trees {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 40vh;
    background: 
        repeating-linear-gradient(90deg,
            transparent 0%, transparent 5%,
            #1a0934 5%, #1a0934 7%,
            transparent 7%, transparent 12%
        ),
        linear-gradient(to top,
            #1a0934 0%,
            #1a0934 40%,
            transparent 100%
        );
    clip-path: polygon(
        0% 100%, 5% 85%, 10% 100%, 15% 90%, 
        20% 100%, 25% 85%, 30% 100%, 35% 90%, 
        40% 100%, 45% 85%, 50% 100%, 55% 90%,
        60% 100%, 65% 85%, 70% 100%, 75% 90%,
        80% 100%, 85% 85%, 90% 100%, 95% 90%,
        100% 100%
    );
}

body {
    min-height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center; /* Horizontal centering */
    align-items: center;    /* Vertical centering */
    background: linear-gradient(135deg, #1e0553 0%, #3d0a6b 100%);
    overflow: hidden;
    position: relative;
}

h1 {
    font-size: 48px;
    font-weight: bold;
    color: #6d38ff;
    text-shadow: 0 0 10px rgba(109, 56, 255, 0.8), 0 0 20px rgba(109, 56, 255, 0.6), 0 0 30px rgba(109, 56, 255, 0.4);
    margin-bottom: 10px;
    text-align: center;
    animation: glow 1.5s ease-in-out infinite;
}

h2 {
    color: white;
    text-align: center;
    margin-bottom: 20px;
    font-size: 28px;
    font-weight: 500;
    line-height: 1.4;
}
.form-group {
    position: relative;
    margin-bottom: 20px;
}

input {
    width: 100%;
    padding: 15px 45px;
    background: rgba(255, 255, 255, 0.1);
    border: none;
    border-radius: 30px;
    color: white;
    font-size: 16px;
    backdrop-filter: blur(5px);
}

input::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

input:focus {
    outline: none;
    background: rgba(255, 255, 255, 0.2);
}

.icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    opacity: 0.7;
}

.options {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 20px 0;
}

.remember {
    display: flex;
    align-items: center;
    gap: 8px;
    color: rgba(255, 255, 255, 0.7);
    font-size: 14px;
}

.remember input[type="checkbox"] {
    width: auto;
    margin-right: 5px;
}

.forgot {
    color: rgba(255, 255, 255, 0.7);
    text-decoration: none;
    font-size: 14px;
    transition: color 0.3s ease;
}

.forgot:hover {
    color: white;
}

.btn-login {
    width: 100%;
    padding: 15px;
    background: linear-gradient(135deg, #9b6dff 0%, #6d38ff 100%);
    border: none;
    border-radius: 30px;
    color: white;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(109, 56, 255, 0.4);
}

.register {
    text-align: center;
    margin-top: 20px;
    color: rgba(255, 255, 255, 0.7);
    font-size: 14px;
}

.register a {
    color: white;
    text-decoration: none;
    font-weight: 500;
}

@keyframes twinkle {
    0%, 100% { opacity: 0.4; }
    50% { opacity: 0.8; }
}

@media (max-width: 480px) {
    .login-container {
        padding: 30px;
    }
}


    </style>
</head>
<body>
    <div class="container" id="signIn">
        <h1 class="form-title text-center"></h1>

        <!-- Display PHP error messages -->
        <?php if ($error): ?>
            <div class="alert alert-danger text-center">
                <?= $error ?>
            </div>
        <?php endif; ?>

    <div class="stars"></div>
    <div class="mountains"></div>
    <div class="trees"></div>
    
    <div class="login-container">
        <h1>StoryLine</h1>
        <h2>Login</h2>
        <form id="logInForm">
            <div class="form-group">
                <input type="text" name="username" id="username" placeholder="Username" required>
                <span class="icon">👤</span>
            </div>
            <div class="form-group">
                <input type="password" name="password" id="password" placeholder="Password" required>
                <span class="icon">🔒</span>
            </div>
            <div class="options">
                <label class="remember">
                    <input type="checkbox" name="remember">
                    <span>Remember me</span>
                </label>
                <a href="#" class="forgot">Forgot Password</a>
            </div>
            <button type="submit" class="btn-login">LOGIN</button>
            <p class="register">Don't have account? <a href="#">Register</a></p>
        </form>
    </div>

    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Include External JavaScript File -->
    <script src="../assets/js/login.js"></script>
</body>
</html>
