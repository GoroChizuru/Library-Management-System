<?php
require "../includes/database.php";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":
        getUser($pdo);
        break;
    case "POST":
        addUser($pdo);
        break;
    case "PUT":
        updateUser($pdo);
        break;
    case "DELETE":
        deleteUser($pdo);
        break;
    default:
        echo json_encode(["error" => "Invalid Request"]);
        http_response_code(400); // Bad Request for invalid methods
        break;
}

function getUser($pdo) {
    // Check if 'id' is set in the query string
    $id = isset($_GET['id']) ? $_GET['id'] : null;

    if ($id) {
        // Fetch a specific user by id
        $sql = "SELECT id, username, password, role FROM tbl_user WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            echo json_encode($user);
        } else {
            echo json_encode(["error" => "User not found"]);
        }
    } else {
        // If no 'id' is provided, return all users
        $sql = "SELECT id, username, role FROM tbl_user";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($users)) {
            echo json_encode(["message" => "No users found"]);
        } else {
            echo json_encode($users);
        }
    }
}


function addUser($pdo) {
    $input = json_decode(file_get_contents("php://input"), true);

    $username = $input['username'] ?? null;
    $password = $input['password'] ?? null;
    $role = $input['role'] ?? null;

    if (!$username || !$password || !$role) {
        echo json_encode(["error" => "All fields are required"]);
        http_response_code(400); // Bad Request if missing fields
        exit;
    }

    // Convert role to lowercase
    $role = strtolower($role);

    // Check if the username already exists in the database
    $sql = "SELECT COUNT(*) FROM tbl_user WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":username", $username);
    $stmt->execute();

    // If the username exists, return an error
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(["error" => "Username already exists"]);
        http_response_code(400); // Bad Request for duplicate username
        exit;
    }

    // Proceed with inserting the new user if no duplicate username
    $sql = "INSERT INTO tbl_user (username, password, role) VALUES (:username, :password, :role)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":username", $username);
    $stmt->bindParam(":password", $password);
    $stmt->bindParam(":role", $role);

    if ($stmt->execute()) {
        echo json_encode(["message" => "User added successfully"]);
        http_response_code(201); // Created if user is added successfully
    } else {
        echo json_encode(["error" => "Error adding user"]);
        http_response_code(500); // Internal Server Error if something goes wrong
    }
}



function deleteUser($pdo) {
    $id = $_GET['id'] ?? null;

    if (!$id) {
        echo json_encode(["error" => "User ID is required"]);
        http_response_code(400); // Bad Request if ID is missing
        exit;
    }

    // Get the role of the user being deleted
    $sql = "SELECT role FROM tbl_user WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(["error" => "User not found"]);
        http_response_code(404); // Not Found if user doesn't exist
        exit;
    }

    // Prevent deletion of admin users
    if ($user['role'] === 'admin') {
        echo json_encode(["error" => "Cannot delete an Admin account"]);
        http_response_code(403); // Forbidden
        exit;
    }

    // Proceed with deletion if the user is not an Admin
    $sql = "DELETE FROM tbl_user WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $id);

    if ($stmt->execute()) {
        echo json_encode(["message" => "User deleted successfully"]);
        http_response_code(200); // OK when deletion is successful
    } else {
        echo json_encode(["error" => "Error deleting user"]);
        http_response_code(500); // Internal Server Error if deletion fails
    }
}

//put
function updateUser($pdo) {
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    if(!$id){
        http_response_code(400);
        echo json_encode(['error' => 'User ID is required']);
        exit;
    }

    // Get input
    $input = json_decode(file_get_contents("php://input"), true);

    $username = isset($input['username']) ? $input['username'] : null;
    $password = isset($input['password']) ? $input['password'] : null;
    $role = isset($input['role']) ? $input['role'] : null;

    // Validation
    if(!$username || !$password || !$role){
        http_response_code(400);
        echo json_encode([
            "error" => "All fields are required"
        ]);
        exit;
    }

    // Convert role to lowercase
    $role = strtolower($role);

    // SQL query
    $sql = "UPDATE tbl_user SET username = :username, password = :password, role = :role WHERE id = :id";

    // Prepare statement
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(":id", $id);
    $stmt->bindParam(":username", $username);
    $stmt->bindParam(":password", $password);
    $stmt->bindParam(":role", $role);

    // Execute the query
    if($stmt->execute()){
        echo json_encode(['message' => 'User updated successfully']);
    } else {
        echo json_encode(['error' => 'Error updating user']);
    }
}

?>
