<?php
require "../includes/database.php"; // Ensure the correct path to your database connection file

header('Content-Type: application/json');
$response = ["totalUsers" => 0, "totalBooks" => 0, "booksBorrowed" => 0];

try {
    // Fetch total users
    $userSql = "SELECT COUNT(*) AS totalUsers FROM tbl_user";
    $userStmt = $pdo->query($userSql);
    $response["totalUsers"] = $userStmt->fetch(PDO::FETCH_ASSOC)["totalUsers"];

    // Fetch total books
    $bookSql = "SELECT COUNT(*) AS totalBooks FROM tbl_book";
    $bookStmt = $pdo->query($bookSql);
    $response["totalBooks"] = $bookStmt->fetch(PDO::FETCH_ASSOC)["totalBooks"];

    // Fetch borrowed books (assuming status = 'borrowed')
    $borrowedSql = "SELECT COUNT(*) AS booksBorrowed FROM tbl_book WHERE status = 'borrowed'";
    $borrowedStmt = $pdo->query($borrowedSql);
    $response["booksBorrowed"] = $borrowedStmt->fetch(PDO::FETCH_ASSOC)["booksBorrowed"];
} catch (PDOException $e) {
    // Log the error and return it (for debugging)
    error_log("Database Error: " . $e->getMessage());
    $response["error"] = "Database error occurred.";
}

echo json_encode($response);
?>
