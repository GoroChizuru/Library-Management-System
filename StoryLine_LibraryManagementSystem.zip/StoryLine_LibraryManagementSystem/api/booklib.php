<?php

 // Set the time zone to Philippine Time
 date_default_timezone_set('Asia/Manila');
// Database connection
require "../includes/database.php";

// Determine request method
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":
        getBooks($pdo);
        break;
    case "PUT":
        updateBook($pdo);
        break;
    default:
        echo json_encode(["error" => "Invalid request method"]);
}

// Get books
function getBooks($pdo)
{
    $id = isset($_GET['bookID']) ? $_GET['bookID'] : null;

    if ($id) {
        $sql = "SELECT bookID, bookTitle, author, status FROM tbl_book WHERE bookID = :bookID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":bookID", $id);
    } else {
        $sql = "SELECT bookID, bookTitle, author, status FROM tbl_book";
        $stmt = $pdo->prepare($sql);
    }

    $stmt->execute();
    $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($books);
}

// Update Book
function updateBook($pdo)
{
    // Get the JSON input
    $inputData = json_decode(file_get_contents('php://input'), true);

    // Check if bookID and status are provided
    if (isset($inputData['bookID']) && isset($inputData['status'])) {
        $bookID = $inputData['bookID'];
        $status = $inputData['status'];
        $currentDateTime = date("Y-m-d H:i:s");

        // Validate status
        if ($status !== 'Available' && $status !== 'Borrowed') {
            echo json_encode(["error" => "Invalid status. It must be 'Available' or 'Borrowed'."]);
            return;
        }

        // Update the book status and relevant date fields
        $sql = "UPDATE tbl_book 
                SET status = :status, 
                    borrowedDate = CASE 
                        WHEN :status = 'Borrowed' THEN :currentDateTime
                        ELSE borrowedDate 
                    END, 
                    returnedDate = CASE 
                        WHEN :status = 'Available' THEN :currentDateTime
                        ELSE returnedDate 
                    END 
                WHERE bookID = :bookID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":currentDateTime", $currentDateTime);
        $stmt->bindParam(":bookID", $bookID);

        if ($stmt->execute()) {
            echo json_encode(["message" => "Book status updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update book status"]);
        }
    } else {
        echo json_encode(["error" => "BookID and status are required"]);
    }
}



?>