<?php
// Include the database connection
require "../includes/database.php";

// Determine the request method
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case "GET":
        getBooks($pdo);
        break;
    case "POST":
        addBook($pdo);
        break;
    case "PUT":
        updateBook($pdo);  // Make sure you're updating the status
        break;
    case "DELETE":
        deleteBook($pdo);
        break;
    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(["error" => "Invalid request method"]);
        exit;
}

// Fetch books (all or single)
function getBooks($pdo) {
    $id = isset($_GET['bookID']) ? $_GET['bookID'] : null;

    if ($id) {
        $sql = "SELECT bookID, bookTitle, author, status FROM tbl_book WHERE bookID = :bookID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":bookID", $id, PDO::PARAM_INT);
        $stmt->execute();
        $book = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode($book);  // Return single book object
    } else {
        $sql = "SELECT bookID, bookTitle, author, status FROM tbl_book";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($books);  // Return all books if no ID is provided
    }
}

function updateBook($pdo) {
    // Get the JSON input
    $inputData = json_decode(file_get_contents('php://input'), true);

    // Debugging: Log the incoming data
    error_log(print_r($inputData, true));

    // Ensure that bookID, bookTitle, author, and status are provided
    if (isset($inputData['bookID']) && isset($inputData['bookTitle']) && isset($inputData['author']) && isset($inputData['status'])) {
        $bookID = $inputData['bookID'];
        $bookTitle = $inputData['bookTitle'];
        $author = $inputData['author'];
        $status = $inputData['status'];

        // Validate status
        if ($status !== 'Available' && $status !== 'Borrowed') {
            echo json_encode(["error" => "Invalid status. It must be 'Available' or 'Borrowed'."]);
            return;
        }

        // Update all fields in the database
        $sql = "UPDATE tbl_book SET bookTitle = :bookTitle, author = :author, status = :status WHERE bookID = :bookID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":bookTitle", $bookTitle);
        $stmt->bindParam(":author", $author);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":bookID", $bookID, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(["message" => "Book updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update book"]);
        }
    } else {
        echo json_encode(["error" => "All fields (bookID, bookTitle, author, status) are required"]);
    }
}

// Add a new book
function addBook($pdo) {
    $input = json_decode(file_get_contents("php://input"), true);

    $bookTitle = $input['bookTitle'] ?? null;
    $author = $input['author'] ?? null;
    $status = $input['status'] ?? null;

    // Validate input
    if (!$bookTitle || !$author || !in_array($status, ['Available', 'Borrowed'])) {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Invalid input. Status must be 'Available' or 'Borrowed'."]);
        exit;
    }

    $sql = "INSERT INTO tbl_book (bookTitle, author, status) VALUES (:bookTitle, :author, :status)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":bookTitle", $bookTitle);
    $stmt->bindParam(":author", $author);
    $stmt->bindParam(":status", $status);

    if ($stmt->execute()) {
        http_response_code(201); // Created
        echo json_encode(["message" => "Book added successfully"]);
    } else {
        http_response_code(500); // Internal Server Error
        echo json_encode(["error" => "Failed to add the book"]);
    }
}

function deleteBook($pdo) {
    $bookID = isset($_GET['bookID']) ? $_GET['bookID'] : null;

    if (!$bookID) {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Book ID is required"]);
        exit;
    }

    // Check if the book is currently borrowed
    $sql = "SELECT status FROM tbl_book WHERE bookID = :bookID";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":bookID", $bookID, PDO::PARAM_INT);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($book) {
        if ($book['status'] === 'Borrowed') {
            // Book cannot be deleted if it's borrowed
            http_response_code(400); // Bad Request
            echo json_encode(["error" => "Cannot delete a borrowed book."]);
            exit;
        } else {
            // Proceed with deleting the book if it's not borrowed
            $sql = "DELETE FROM tbl_book WHERE bookID = :bookID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(":bookID", $bookID, PDO::PARAM_INT);

            if ($stmt->execute()) {
                if ($stmt->rowCount() > 0) {
                    echo json_encode(["message" => "Book deleted successfully"]);
                } else {
                    http_response_code(404); // Not Found
                    echo json_encode(["error" => "Book not found"]);
                }
            } else {
                http_response_code(500); // Internal Server Error
                echo json_encode(["error" => "Failed to delete the book"]);
            }
        }
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "Book not found"]);
    }
}

?>
