<?php
// Include FPDF library
require('./fpdf/fpdf.php');
require('../includes/database.php');

// Generate Combined Report
function generateBooksReport($pdo, $status = null) {
    // Set headers for inline PDF display
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="library_report.pdf"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');

    // Initialize FPDF in Landscape mode
    $pdf = new FPDF('L', 'mm', 'A4');
    $pdf->SetFont('Arial', 'B', 16);

    // Report Header
    $title = $status ? ucfirst($status) . " Books Report" : "Library Book Report";
    $pdf->AddPage();
    $pdf->Cell(0, 10, $title, 0, 1, 'C');
    $pdf->Ln(10);

    // Fetch books from the database
    $bookSql = "SELECT bookID, bookTitle, author, status, borrowedDate, returnedDate FROM tbl_book";
    if ($status) {
        $bookSql .= " WHERE status = :status";
    }
    $bookStmt = $pdo->prepare($bookSql);
    if ($status) {
        $bookStmt->bindParam(':status', $status, PDO::PARAM_STR);
    }
    $bookStmt->execute();
    $books = $bookStmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if there are any books
    if (count($books) === 0) {
        $pdf->SetFont('Arial', 'I', 12);
        $pdf->Cell(0, 10, 'No records found.', 1, 1, 'C');
    } else {
        // Table Header
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(10, 10, 'ID', 1);
        $pdf->Cell(90, 10, 'Title', 1);
        $pdf->Cell(80, 10, 'Author', 1);
        $pdf->Cell(20, 10, 'Status', 1);
        $pdf->Cell(41, 10, 'Borrowed Date', 1);
        $pdf->Cell(41, 10, 'Returned Date', 1);
        $pdf->Ln();

        // Table Content
        $pdf->SetFont('Arial', '', 12);
        foreach ($books as $book) {
            $pdf->Cell(10, 10, $book['bookID'], 1);
            $pdf->Cell(90, 10, iconv('UTF-8', 'ISO-8859-1', $book['bookTitle']), 1);
            $pdf->Cell(80, 10, iconv('UTF-8', 'ISO-8859-1', $book['author']), 1);
            $pdf->Cell(20, 10, $book['status'], 1);
            $pdf->Cell(41, 10, $book['borrowedDate'] ?: '-', 1);
            $pdf->Cell(41, 10, $book['returnedDate'] ?: '-', 1);
            $pdf->Ln();
        }
    }

    // Output PDF
    $pdf->Output('I', 'library_report.pdf'); // 'I' for inline display
}


// Process Request
$status = isset($_GET['status']) ? $_GET['status'] : null;
generateBooksReport($pdo, $status);


