Group 6: 
Leader - PALAY, Dylan Dinesen P.
Members: 
1.  LICUDAN, Christian Miguel S.
2.  TEAÑO, Ezekial T.
3.  SALTING, James Bryan M.

StoryLine
Overview

StoryLine is a complete library management system that simplifies the administration of library materials and user interactions. StoryLine, built with PHP, JavaScript, and CSS, has an easy-to-use interface and good functionality for both admins and librarians.

Key Features:

User Management: Admin may add, update, and delete Librarian accounts to ensure proper user management.
Admins may manage the library's book inventory by adding, amending, and removing books. Librarians can change the status of a book (borrowed or available).
Report Generation: Admin can select books by status and export them as PDFs for convenient distribution and analysis.
Borrow/Return System: Librarians may control the borrowing and return of books, altering their status accordingly.

Getting started

Set up the StoryLine Library Management System:
Clone the repository on your local workstation.
Enable the Apache Server and MySQL Database in the XAMPP Control Panel.
Set up the database connection in /config/database.php.
Import the given SQL schema into the root file to generate the appropriate database tables.
Transfer your folder to the htdocs folder in the XAMPP installation directory.
Log in to the application using your web server's Admin or Librarian credentials.
Conclusion
StoryLine is intended to improve the efficiency of library administration with its user-friendly interface and robust capabilities. With the capacity to manage users, books, and create reports, it is an essential tool for modern libraries.
