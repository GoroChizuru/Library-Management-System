<?php
require "includes/auth.php";

// Redirect to appropriate dashboard based on role
if (isset($_SESSION["role"])) {
    if ($_SESSION["role"] === "admin") {
        header("Location: views/admin/dashboard.php");
        exit();
    } elseif ($_SESSION["role"] === "librarian") {
        header("Location: views/librarian/borrow_return.php");
        exit();
    }
} else {
    // Redirect to login if not logged in
    header("Location: views/login.php");
    exit();
}
?>
