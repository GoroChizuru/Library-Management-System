<?php
session_start();

/**
 * Function to check the user's role and redirect if unauthorized.
 * 
 * @param string $required_role The role required to access the page.
 * @param string $redirect_path The path to redirect unauthorized users.
 */
function check_role($required_role, $redirect_path = "views/login.php") {
    if (!isset($_SESSION["role"]) || $_SESSION["role"] !== $required_role) {
        header("Location: $redirect_path");
        exit();
    }
}
