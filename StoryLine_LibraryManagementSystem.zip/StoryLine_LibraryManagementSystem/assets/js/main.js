function fetchDashboardStats() {
    fetch('../../api/dashboard_stats.php') // Ensure the correct path to your API
        .then((response) => {
            if (!response.ok) {
                throw new Error(`Network response was not ok: ${response.statusText}`);
            }
            return response.json(); // Convert the response to JSON
        })
        .then((data) => {
            console.log('Fetched Data:', data); // Log the fetched data to console
            if (data && typeof data === 'object') {
                // Update the DOM with fetched data
                document.getElementById('total-users').textContent = data.totalUsers || 0;
                document.getElementById('total-books').textContent = data.totalBooks || 0;
                document.getElementById('books-borrowed').textContent = data.booksBorrowed || 0;
            } else {
                throw new Error('Invalid data format received.');
            }
        })
        .catch((error) => {
            console.error('Fetch error:', error); // Detailed error log
            alert('Failed to fetch dashboard statistics. Please try again later.');
        });
}

document.addEventListener('DOMContentLoaded', fetchDashboardStats);
