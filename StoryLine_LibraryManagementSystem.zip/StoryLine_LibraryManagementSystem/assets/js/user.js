let idToEdit = null; // Global variable to track the user being edited

// Function to handle form submission
function handleUserForm() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const role = document.getElementById("role").value.toLowerCase(); // Convert role to lowercase

  // Validate form input
  if (!username || !password || !role) {
    alert("Please fill all fields");
    return;
  }

  const dataToSubmit = { username, password, role };

  if (idToEdit) {
    // Update user if idToEdit is set
    updateUser(dataToSubmit);
  } else {
    // Create a new user if no edit ID
    insertData(dataToSubmit);
  }
}


// Fetch and display users
function getUsers() {
  fetch("../../api/user.php")
    .then((response) => response.json())
    .then((data) => displayUsers(data))
    .catch((err) => console.error("Error fetching users:", err));
}

// Display users in the table
function displayUsers(userData) {
  const userDisplay = document.getElementById("user-display");
  userDisplay.innerHTML = ""; // Clear the table before populating
  if (userData.message) {
    userDisplay.innerHTML = `<tr><td colspan="5" class="text-center">${userData.message}</td></tr>`;
  } else if (userData.length === 0) {
    userDisplay.innerHTML = `<tr><td colspan="5" class="text-center">No users found.</td></tr>`;
  } else {
    userData.forEach((data) => {
      let row = `
        <tr id="user-${data.id}">
          <td>${data.id}</td>
          <td>${data.username}</td>
          <td>********</td> <!-- Display ******** instead of the actual password -->
          <td>${data.role}</td>
          <td>
            <button onclick="editUser(${data.id})" class="btn btn-warning btn-sm">Edit</button>
            <button onclick="deleteUser(${data.id})" class="btn btn-danger btn-sm">Delete</button>
          </td>
        </tr>`;
      userDisplay.innerHTML += row;
    });
  }
}



function insertData(dataToSubmit) {
  fetch("../../api/user.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dataToSubmit),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        // If there's an error (like username already exists), show the error message
        Swal.fire({
          title: "Error!",
          text: data.error, // Display the error message from the PHP response
          icon: "error"
        });
      } else {
        // Success message if no error
        Swal.fire({
          title: "User is Created!",
          text: ":)",
          icon: "success"
        });
        document.getElementById("userForm").reset();
        getUsers(); // Refresh the user table
      }
    })
    .catch((err) => console.error("Error adding user:", err));
}


// Open the edit modal and populate its fields
async function editUser(id) {
  try {
    const response = await fetch(`../../api/user.php?id=${id}`);
    const user = await response.json();

    if (user) {
      document.getElementById("edit-user-id").value = id;
      document.getElementById("edit-username").value = user.username;
      document.getElementById("edit-password").value = user.password;
      document.getElementById("edit-role").value = user.role;

      // Show the modal
      const editUserModal = new bootstrap.Modal(document.getElementById("editUserModal"));
      editUserModal.show();
    } else {
      alert("User data not found in the database.");
    }
  } catch (err) {
    console.error("Error fetching user for edit:", err);
  }
}

// Update user details from the modal
function updateUserFromModal() {
  const id = document.getElementById("edit-user-id").value;
  const username = document.getElementById("edit-username").value;
  const password = document.getElementById("edit-password").value;
  const role = document.getElementById("edit-role").value.toLowerCase(); // Convert role to lowercase

  const dataToSubmit = { username, password, role };

  fetch(`../../api/user.php?id=${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dataToSubmit),
  })
    .then((response) => response.json())
    .then((data) => {
      Swal.fire({
        title: "User updated",
        text: ":)",
        icon: "success"
      });

      // Close the modal
      const editUserModal = bootstrap.Modal.getInstance(document.getElementById("editUserModal"));
      editUserModal.hide();

      getUsers(); // Refresh the user table
    })
    .catch((err) => console.error("Error updating user:", err));
}

// Delete a user
async function deleteUser(id) {
  try {
    // Show confirmation dialog
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "Cancel"
    });

    // Check if the user confirmed the action
    if (result.isConfirmed) {
      // Perform the delete request
      const response = await fetch(`../../api/user.php?id=${id}`, { method: "DELETE" });
      const data = await response.json();

      if (data.error) {
        // If the error is because the user is an admin, show an alert
        if (data.error === "Cannot delete an Admin account") {
          Swal.fire({
            title: "Error!",
            text: "You cannot delete an Admin account.",
            icon: "error"
          });
        } else {
          // Show general error message
          Swal.fire({
            title: "Error!",
            text: data.error || "Failed to delete the user. Please try again later.",
            icon: "error"
          });
        }
      } else {
        // Success notification if the user is deleted
        Swal.fire({
          title: "Deleted!",
          text: data.message || "User deleted successfully.",
          icon: "success"
        });

        // Refresh the user list or perform any necessary updates
        getUsers(); // Ensure `getUsers` is defined elsewhere
      }
    }
  } catch (error) {
    console.error("Error deleting user:", error);

    // Show an error notification
    Swal.fire({
      title: "Error!",
      text: "Failed to delete the user. Please try again later.",
      icon: "error"
    });
  }
}


// Load users on page load
window.onload = getUsers;
