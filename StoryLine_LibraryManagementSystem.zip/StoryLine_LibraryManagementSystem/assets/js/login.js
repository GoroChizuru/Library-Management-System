// Get the form element
const logInForm = document.getElementById("logInForm");

// Prevent form submission and handle login
logInForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const username = document.querySelector("#username").value.trim();
    const password = document.querySelector("#password").value.trim();

    // Check if username or password is empty
    if (username === "" || password === "") {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Please enter both username and password!",
            confirmButtonColor: "#f65867",
        });
        return;
    }

    // Send login request to the PHP server
    fetch("../api/auth.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.error) {
                // Show error message
                Swal.fire({
                    icon: "error",
                    title: "Oops",
                    text: data.error,
                    confirmButtonColor: "#5ec293",
                });
            } else {
                // Save session data
                sessionStorage.setItem("username", data.username);
                sessionStorage.setItem("role", data.role);

                // Show success message
                Swal.fire({
                    icon: "success",
                    title: "Welcome back!",
                    text: `Hello, ${data.username}! You are logged in as ${data.role}.`,
                    confirmButtonColor: "#3085d6",
                }).then(() => {
                    // Redirect based on user role after closing the success message
                    if (data.role === "admin") {
                        window.location.href = "admin/dashboard.php";
                    } else if (data.role === "librarian") {
                        window.location.href = "librarian/borrow_return.php";
                    }
                });
            }
        })
        .catch((error) => {
            console.error(error);
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Error connecting to the server!",
                confirmButtonColor: "#f65867",
            });
        });
});

// Prevent links with the "link-no-submit" class from triggering form submit
document.querySelectorAll(".link-no-submit").forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        const target = e.target.getAttribute("href");
        if (target) {
            window.location.href = target;
        }
    });
});
