// Fetch and display books
async function getBooks() {
    try {
        const response = await fetch("../../api/book.php");
        const books = await response.json();
        displayBooks(books);
    } catch (err) {
        console.error("Error fetching books:", err);
    }
}

// Populate table with books and display status directly (no toggle switch)
function displayBooks(bookData) {
    const bookDisplay = document.getElementById("book-display");
    bookDisplay.innerHTML = ""; 
    bookData.forEach((book) => {
        bookDisplay.innerHTML += `
            <tr>
                <td>${book.bookID}</td>
                <td>${book.bookTitle}</td>
                <td>${book.author}</td>
                <td>${book.status}</td> <!-- Display status directly -->
                <td>
                    <button onclick="editBook(${book.bookID})" class="btn btn-warning btn-sm">Edit</button>
                    <button onclick="deleteBook(${book.bookID})" class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
        `;
    });
}

// Add book
document.getElementById("bookForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const bookTitle = document.getElementById("bookTitle").value;
    const author = document.getElementById("author").value;
    const status = document.getElementById("status").value;

    try {
        const response = await fetch("../../api/book.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bookTitle, author, status }),
        });
        const data = await response.json();
        Swal.fire({
            title: "Book Added",
            text: ":)",
            icon: "success"
        });
        document.getElementById("bookForm").reset();
        getBooks();
    } catch (err) {
        console.error("Error adding book:", err);
    }
});

// Edit book
async function editBook(bookID) {
    try {
        const response = await fetch(`../../api/book.php?bookID=${bookID}`);
        const book = await response.json(); // Expecting a single book object, not an array
        if (book) {
            // Populate modal fields
            document.getElementById("edit-book-id").value = book.bookID;
            document.getElementById("edit-book-title").value = book.bookTitle;
            document.getElementById("edit-author").value = book.author;
            document.getElementById("edit-status").value = book.status;

            // Open the modal
            new bootstrap.Modal(document.getElementById("editBookModal")).show();
        } else {
            alert("Book not found!");
        }
    } catch (err) {
        console.error("Error fetching book:", err);
    }
}

async function updateBookFromModal() {
    const bookID = document.getElementById("edit-book-id").value;
    const bookTitle = document.getElementById("edit-book-title").value;
    const author = document.getElementById("edit-author").value;
    const status = document.getElementById("edit-status").value;

    if (!bookID || !bookTitle || !author || !status) {
        alert("Please fill in all fields.");
        return;
    }

    try {
        const response = await fetch("../../api/book.php", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                bookID,  // Ensure these fields are correctly populated
                bookTitle,
                author,
                status
            }),
        });

        const data = await response.json();

        if (data.message) {
            Swal.fire({
                title: "Book Updated",
                text: ":)",
                icon: "success"
            });
            getBooks();  // Refresh the books list
            const modal = bootstrap.Modal.getInstance(document.getElementById("editBookModal"));
            modal.hide();  // Correctly close the modal using Bootstrap's instance method
        } else {
            Swal.fire({
                icon: "error",
                title: "Error",
                text: data.error || "Something went wrong.",
                confirmButtonColor: "#f65867",
            });
        }
    } catch (err) {
        console.error("Error updating book:", err);
        Swal.fire({
            icon: "error",
            title: "Error",
            text: "There was an error updating the book.",
            confirmButtonColor: "#f65867",
        });
    }
}

// Delete book
async function deleteBook(bookID) {
    const result = await Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel"
    });

    if (result.isConfirmed) {
        try {
            const response = await fetch(`../../api/book.php?bookID=${bookID}`, { method: "DELETE" });
            const data = await response.json();

            if (data.error) {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: data.error,
                    confirmButtonColor: "#f65867",
                });
            } else {
                Swal.fire({
                    title: "Book Deleted",
                    text: ":)",
                    icon: "success"
                });
                getBooks();
            }
        } catch (err) {
            console.error("Error deleting book:", err);
        }
    }
}

// Initial fetch to load books
getBooks();
