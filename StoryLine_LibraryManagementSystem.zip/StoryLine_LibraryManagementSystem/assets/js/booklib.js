// Function to get books and display them
function getBooks() {
  fetch("../../api/booklib.php")
    .then((response) => response.json())
    .then((data) => displayBooks(data))
    .catch((err) => {
      console.error("Error fetching books:", err);
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Error fetching books. Please try again later.",
        confirmButtonColor: "#f65867",
      });
    });
}

// Function to display books in the table with toggle switches
function displayBooks(bookData) {
  const bookDisplay = document.getElementById("book-display");
  bookDisplay.innerHTML = ""; // Clear the table before populating

  bookData.forEach((data) => {
      let isChecked = data.status === "Available" ? "checked" : "";
      let switchColorClass =
          data.status === "Available" ? "bg-success" : "bg-danger";

      let row = `
          <tr>
              <td>${data.bookID}</td>
              <td>${data.bookTitle}</td>
              <td>${data.author}</td>
              <td>
                  <div class="form-check form-switch">
                      <input 
                          class="form-check-input toggle-status ${switchColorClass}" 
                          type="checkbox" 
                          id="book-${data.bookID}" 
                          data-id="${data.bookID}" 
                          ${isChecked} 
                          onchange="toggleBookStatus(${data.bookID}, this.checked)">
                      <label class="form-check-label" for="book-${data.bookID}">
                          <span class="${switchColorClass} text-white px-2 py-1 rounded">
                              ${data.status}
                          </span>
                      </label>
                  </div>
              </td>
              <td class="hidden">${data.borrowedDate || '-'}</td>
              <td class="hidden">${data.returnedDate || '-'}</td>
          </tr>
      `;
      bookDisplay.innerHTML += row;
  });
}


// Function to update book status
function toggleBookStatus(bookID, isAvailable) {
  const newStatus = isAvailable ? "Available" : "Borrowed";

  fetch("../../api/booklib.php", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      bookID: bookID,
      status: newStatus,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.message) {
        Swal.fire({
          icon: "success",
          title: "Success",
          text: data.message || "Book status updated successfully.",
          confirmButtonColor: "#3085d6",
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Oops",
          text: data.error || "Something went wrong.",
          confirmButtonColor: "#f65867",
        });
      }
      getBooks(); // Reload the books to show updated status
    })
    .catch((error) => {
      console.error("Error updating book status:", error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "There was an error updating the book status.",
        confirmButtonColor: "#f65867",
      });
    });
}

// Load books on page load
window.onload = () => getBooks();
